
class FactSales:
    def __init__(self, customer, product, date, region, quantity, total_sales):
        self.customer = customer
        self.product = product
        self.date = date
        self.region = region
        self.quantity = quantity
        self.total_sales = total_sales
